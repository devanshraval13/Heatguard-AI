# HeatGuard AI — Climate Intelligence for Heatwave Monitoring, Prediction & Early Warning

**Use case:** KJS-CES-01 · Climate, Energy & Sustainability  
**Application:** React + Hooks + React Router + Node.js + Express REST API + SQLite SQL + MongoDB NoSQL  
**Audience:** disaster management teams, municipal corporations, agricultural agencies, health departments and citizens.

> Academic/demo project. All included readings are sample data; this app is not connected to a live IMD feed and does not provide official forecasts or emergency warnings.

## Practical coverage

1. **Basic React web page design:** responsive dashboard, navigation, cards, data tables and alert badges.
2. **React Hooks:** `useState`, `useEffect`, `useMemo`, `useCallback`.
3. **Forms and validation:** required fields, numeric ranges, coordinates and alert severity validation in UI/API.
4. **API integration:** React `fetch` wrapper in `frontend/src/api.js`, loading and error handling.
5. **Node.js:** ES module backend.
6. **Express routing:** REST endpoints with JSON request/response and HTTP status codes.
7. **SQL + NoSQL CRUD:** SQLite tables (`stations`, `alerts`) and MongoDB collections (`stations`, `alerts`) each have Create, Read, Update, Delete endpoints.
8. **React + Node REST integration:** Vite frontend calls Express at port 5000.
9. **Postman:** import `postman/HeatGuard_AI_API.postman_collection.json`.

## Requirements

- Node.js 18+ (Node 20 LTS recommended) and npm
- MongoDB Community Server running locally **or** a MongoDB Atlas cluster
- VS Code and Postman (for API testing)

## Run on Windows (recommended: manual steps)

### A. Configure MongoDB first

**Option 1 — local MongoDB:** install and start MongoDB Community Server, then use `mongodb://127.0.0.1:27017`.

**Option 2 — MongoDB Atlas:** create a free cluster, create a database user, allow your current IP in Network Access, and copy the driver connection string. Replace the username/password/cluster placeholders. Encode special characters in the password. Do not share your connection string.

Open `backend/.env.example`, copy it to `backend/.env`, and set:

```env
PORT=5000
MONGODB_URI=mongodb://127.0.0.1:27017
MONGODB_DATABASE=heatguard_ai
```

For Atlas, replace the URI with your Atlas URI. **MongoDB routes return a clear 503 error until this is configured and reachable; SQLite CRUD still works independently.**

### B. Start backend

Open Terminal 1 in the project root:

```powershell
cd backend
Copy-Item .env.example .env
# Edit .env and set MONGODB_URI before testing MongoDB
npm install
npm run dev
```

If PowerShell says `npm.ps1 cannot be loaded because running scripts is disabled`, use `npm.cmd` instead:

```powershell
npm.cmd install
npm.cmd run dev
```

Backend: `http://localhost:5000`. Keep this terminal open.

### C. Start frontend

Open Terminal 2 at the project root:

```powershell
cd frontend
npm install
npm run dev
```

Open the exact local URL printed by Vite, normally `http://localhost:5173`.

**Shortcut:** after editing `backend/.env`, you can double-click `START_BACKEND.bat` and `START_FRONTEND.bat` in separate windows.

## Verify services

- `GET http://localhost:5000/api/health` — backend and SQL status
- `GET http://localhost:5000/api/nosql/health` — MongoDB connection test
- `GET http://localhost:5000/api/summary` — dashboard metrics
- `GET http://localhost:5000/api/stations` — SQL station records
- `GET http://localhost:5000/api/alerts` — SQL alert records
- `GET http://localhost:5000/api/nosql/stations` — MongoDB station documents
- `GET http://localhost:5000/api/nosql/alerts` — MongoDB alert documents
- `GET http://localhost:5000/api/advisories` — sample advisories

## REST API reference

All routes use base URL `http://localhost:5000`. Send JSON bodies with `Content-Type: application/json`.

| Database | Resource | GET | POST | PUT | DELETE |
|---|---|---|---|---|---|
| SQL / SQLite | Stations | `/api/stations` | `/api/stations` | `/api/stations/:id` | `/api/stations/:id` |
| SQL / SQLite | Alerts | `/api/alerts` | `/api/alerts` | `/api/alerts/:id` | `/api/alerts/:id` |
| NoSQL / MongoDB | Stations | `/api/nosql/stations` | `/api/nosql/stations` | `/api/nosql/stations/:id` | `/api/nosql/stations/:id` |
| NoSQL / MongoDB | Alerts | `/api/nosql/alerts` | `/api/nosql/alerts` | `/api/nosql/alerts/:id` | `/api/nosql/alerts/:id` |

Example station JSON:

```json
{
  "name": "Pune Test AWS",
  "region": "West",
  "city": "Pune",
  "temperature": 41.5,
  "humidity": 25,
  "latitude": 18.5204,
  "longitude": 73.8567
}
```

Example alert JSON:

```json
{
  "title": "High heat stress",
  "region": "West",
  "severity": "Orange",
  "message": "Sample demonstration alert.",
  "status": "Active"
}
```

For PUT/DELETE, use the SQL numeric ID or MongoDB ObjectId returned by POST. Import the Postman collection for ready-to-run examples.

## Postman steps

1. Open Postman → Import.
2. Select `postman/HeatGuard_AI_API.postman_collection.json`.
3. Test Health & dashboard first.
4. Run SQL Create station; copy the returned `id` into the `stationId` collection variable to test SQL update/delete.
5. Confirm `GET /api/nosql/health` reports `connected`. Run MongoDB Create station; copy the returned ObjectId into `mongoStationId` for update/delete. Repeat for alerts.

## Folder structure

```text
HeatGuard_AI_Mini_Project/
├── backend/             # Express API, SQLite and MongoDB adapters
├── frontend/            # React/Vite app and CSS
├── postman/             # Importable API collection
├── START_BACKEND.bat
├── START_FRONTEND.bat
└── README.md
```

## Common errors

- **`npm.ps1` blocked:** use `npm.cmd install` and `npm.cmd run dev`.
- **Port 5000 busy:** change `PORT` in `backend/.env`, then update `VITE_API_URL` or frontend API base to match.
- **MongoDB 503 / server selection timeout:** verify `MONGODB_URI`, that MongoDB is running, Atlas Network Access IP allowlist, DB user/password, and network connectivity.
- **Vite blank / API errors:** keep both terminals running; open the Vite URL and check the browser console.
- **No live climate data:** this is intentional; demo data is simulated and must not be treated as official IMD information.

## Viva quick points

- `useState` stores UI state; `useEffect` loads API data; `useMemo` computes derived values; `useCallback` memoizes handlers.
- Express maps HTTP methods to CRUD: POST/Create, GET/Read, PUT/Update, DELETE/Delete.
- SQLite is relational (tables and rows); MongoDB is document-oriented (collections and BSON documents).
- REST sends JSON over HTTP; React is the client and Express is the API server.
- Validation is done in the frontend for usability and again in the backend for data integrity.
