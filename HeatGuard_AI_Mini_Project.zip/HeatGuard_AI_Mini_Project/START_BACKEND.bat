@echo off
cd /d "%~dp0backend"
if not exist .env copy .env.example .env
call npm.cmd install
call npm.cmd run dev
pause
