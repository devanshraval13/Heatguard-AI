import Database from "better-sqlite3";

const db = new Database("heatguard.sqlite");
db.pragma("journal_mode = WAL");

db.exec(`
  CREATE TABLE IF NOT EXISTS stations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    region TEXT NOT NULL,
    city TEXT NOT NULL,
    temperature REAL NOT NULL,
    humidity INTEGER NOT NULL,
    latitude REAL NOT NULL,
    longitude REAL NOT NULL,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS alerts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    region TEXT NOT NULL,
    severity TEXT NOT NULL,
    message TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'Active',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
`);

const stationCount = db.prepare("SELECT COUNT(*) AS count FROM stations").get().count;
if (stationCount === 0) {
  const insert = db.prepare(`INSERT INTO stations
    (name, region, city, temperature, humidity, latitude, longitude) VALUES (?, ?, ?, ?, ?, ?, ?)`);
  [
    ["Pune Central AWS","West","Pune",41.2,24,18.5204,73.8567],
    ["Mumbai Coastal AWS","West","Mumbai",36.8,58,19.0760,72.8777],
    ["Nagpur City AWS","Central","Nagpur",43.1,19,21.1458,79.0882],
    ["Ahmedabad AWS","West","Ahmedabad",42.4,21,23.0225,72.5714],
    ["Jaipur AWS","North","Jaipur",40.7,18,26.9124,75.7873],
    ["Hyderabad AWS","South","Hyderabad",39.3,31,17.3850,78.4867]
  ].forEach(s => insert.run(...s));
}
const alertCount = db.prepare("SELECT COUNT(*) AS count FROM alerts").get().count;
if (alertCount === 0) {
  const insert = db.prepare("INSERT INTO alerts (title, region, severity, message, status) VALUES (?, ?, ?, ?, ?)");
  [
    ["Extreme heat conditions","Central","Red","Sample reading exceeds 43°C. Verify local conditions and follow official guidance.","Active"],
    ["High heat stress","West","Orange","High temperature and low humidity may increase heat stress risk.","Active"],
    ["Elevated daytime temperature","North","Yellow","Monitor updated forecasts and hydration guidance.","Monitoring"]
  ].forEach(a => insert.run(...a));
}
export default db;
