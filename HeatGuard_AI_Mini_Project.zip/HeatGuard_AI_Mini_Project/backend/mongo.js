import { MongoClient, ObjectId } from "mongodb";

let client;
let database;

export async function getMongoClient() {
  const uri = process.env.MONGODB_URI;
  if (!uri) throw new Error("MongoDB is not configured. Add MONGODB_URI to backend/.env.");
  if (!client) {
    client = new MongoClient(uri, { serverSelectionTimeoutMS: 7000 });
    try { await client.connect(); database = client.db(process.env.MONGODB_DATABASE || "heatguard_ai"); }
    catch (error) { client = undefined; throw new Error(`Could not connect to MongoDB: ${error.message}`); }
  }
  return client;
}
export async function getStationCollection() {
  await getMongoClient();
  const collection = database.collection("stations");
  await collection.createIndex({ name: 1 });
  await collection.createIndex({ region: 1, temperature: -1 });
  return collection;
}
export async function getAlertCollection() {
  await getMongoClient();
  const collection = database.collection("alerts");
  await collection.createIndex({ severity: 1, status: 1 });
  return collection;
}
export { ObjectId };
