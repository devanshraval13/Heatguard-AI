import "dotenv/config";
import express from "express";
import cors from "cors";
import db from "./db.js";
import { getStationCollection, getAlertCollection, getMongoClient, ObjectId } from "./mongo.js";

const app = express();
const PORT = Number(process.env.PORT || 5000);
app.use(cors({ origin: true }));
app.use(express.json());

const regions = ["North","South","East","West","Central","North-East","North-West"];
const severityFor = (temperature) => temperature >= 43 ? "Red" : temperature >= 40 ? "Orange" : temperature >= 37 ? "Yellow" : "Green";
const validateStation = (body) => {
  const errors = [];
  if (!body.name?.trim()) errors.push("Station name is required.");
  if (!body.region?.trim()) errors.push("Region is required.");
  if (!body.city?.trim()) errors.push("City is required.");
  const t = Number(body.temperature), h = Number(body.humidity);
  const lat = Number(body.latitude), lon = Number(body.longitude);
  if (!Number.isFinite(t) || t < -10 || t > 60) errors.push("Temperature must be between -10°C and 60°C.");
  if (!Number.isInteger(h) || h < 0 || h > 100) errors.push("Humidity must be an integer from 0 to 100.");
  if (!Number.isFinite(lat) || lat < -90 || lat > 90) errors.push("Latitude must be between -90 and 90.");
  if (!Number.isFinite(lon) || lon < -180 || lon > 180) errors.push("Longitude must be between -180 and 180.");
  return errors;
};
const validateAlert = (b) => {
  const errors = [];
  if (!b.title?.trim()) errors.push("Alert title is required.");
  if (!b.region?.trim()) errors.push("Region is required.");
  if (!["Red","Orange","Yellow","Green"].includes(b.severity)) errors.push("Choose a valid severity.");
  if (!b.message?.trim()) errors.push("Alert message is required.");
  return errors;
};
const stationShape = (row) => ({ ...row, temperature: Number(row.temperature), humidity: Number(row.humidity), latitude: Number(row.latitude), longitude: Number(row.longitude) });

app.get("/api/health", (_req,res) => res.json({ status:"ok", service:"HeatGuard AI API", time:new Date().toISOString(), sql:"connected", mongoConfigured:Boolean(process.env.MONGODB_URI) }));
app.get("/api/nosql/health", async (_req,res) => {
  try { const client = await getMongoClient(); await client.db(process.env.MONGODB_DATABASE || "heatguard_ai").command({ ping: 1 }); res.json({status:"connected", database:process.env.MONGODB_DATABASE || "heatguard_ai"}); }
  catch(e) { res.status(503).json({status:"disconnected", message:e.message, configured:Boolean(process.env.MONGODB_URI)}); }
});
app.get("/api/summary", (_req,res) => {
  const stations = db.prepare("SELECT * FROM stations").all();
  const alerts = db.prepare("SELECT * FROM alerts").all();
  res.json({
    stationCount: stations.length,
    averageTemperature: stations.length ? Number((stations.reduce((sum,s)=>sum+s.temperature,0)/stations.length).toFixed(1)) : 0,
    hottestStation: stations.sort((a,b)=>b.temperature-a.temperature)[0] || null,
    activeAlerts: alerts.filter(a=>a.status==="Active").length,
    redAlerts: alerts.filter(a=>a.severity==="Red" && a.status==="Active").length,
    regionalCounts: regions.map(region=>({region,count:db.prepare("SELECT COUNT(*) AS count FROM stations WHERE region=?").get(region).count}))
  });
});

// SQL: Stations CRUD
app.get("/api/stations", (req,res) => {
  const search = String(req.query.search || "").trim();
  const rows = search
    ? db.prepare("SELECT * FROM stations WHERE name LIKE ? OR city LIKE ? OR region LIKE ? ORDER BY temperature DESC").all(`%${search}%`,`%${search}%`,`%${search}%`)
    : db.prepare("SELECT * FROM stations ORDER BY temperature DESC").all();
  res.json(rows.map(stationShape));
});
app.post("/api/stations", (req,res) => {
  const errors = validateStation(req.body);
  if (errors.length) return res.status(400).json({message:"Validation failed",errors});
  const b = req.body;
  const result = db.prepare(`INSERT INTO stations (name,region,city,temperature,humidity,latitude,longitude)
    VALUES (@name,@region,@city,@temperature,@humidity,@latitude,@longitude)`).run({
      name:b.name.trim(),region:b.region,city:b.city.trim(),temperature:Number(b.temperature),humidity:Number(b.humidity),
      latitude:Number(b.latitude),longitude:Number(b.longitude)
    });
  res.status(201).json(stationShape(db.prepare("SELECT * FROM stations WHERE id=?").get(result.lastInsertRowid)));
});
app.put("/api/stations/:id", (req,res) => {
  const errors = validateStation(req.body);
  if (errors.length) return res.status(400).json({message:"Validation failed",errors});
  const existing = db.prepare("SELECT id FROM stations WHERE id=?").get(Number(req.params.id));
  if (!existing) return res.status(404).json({message:"Station not found"});
  const b=req.body;
  db.prepare(`UPDATE stations SET name=?,region=?,city=?,temperature=?,humidity=?,latitude=?,longitude=?,updated_at=CURRENT_TIMESTAMP WHERE id=?`)
    .run(b.name.trim(),b.region,b.city.trim(),Number(b.temperature),Number(b.humidity),Number(b.latitude),Number(b.longitude),Number(req.params.id));
  res.json(stationShape(db.prepare("SELECT * FROM stations WHERE id=?").get(Number(req.params.id))));
});
app.delete("/api/stations/:id", (req,res) => {
  const result = db.prepare("DELETE FROM stations WHERE id=?").run(Number(req.params.id));
  if (!result.changes) return res.status(404).json({message:"Station not found"});
  res.json({message:"Station deleted"});
});

// SQL: Alerts CRUD
app.get("/api/alerts", (_req,res) => res.json(db.prepare("SELECT * FROM alerts ORDER BY id DESC").all()));
app.post("/api/alerts", (req,res) => {
  const errors=validateAlert(req.body);
  if(errors.length) return res.status(400).json({message:"Validation failed",errors});
  const b=req.body;
  const result=db.prepare("INSERT INTO alerts (title,region,severity,message,status) VALUES (?,?,?,?,?)")
    .run(b.title.trim(),b.region,b.severity,b.message.trim(),b.status || "Active");
  res.status(201).json(db.prepare("SELECT * FROM alerts WHERE id=?").get(result.lastInsertRowid));
});
app.put("/api/alerts/:id", (req,res) => {
  const errors=validateAlert(req.body);
  if(errors.length) return res.status(400).json({message:"Validation failed",errors});
  const id=Number(req.params.id), old=db.prepare("SELECT * FROM alerts WHERE id=?").get(id);
  if(!old) return res.status(404).json({message:"Alert not found"});
  const b=req.body;
  db.prepare("UPDATE alerts SET title=?,region=?,severity=?,message=?,status=? WHERE id=?")
    .run(b.title.trim(),b.region,b.severity,b.message.trim(),b.status || old.status,id);
  res.json(db.prepare("SELECT * FROM alerts WHERE id=?").get(id));
});
app.delete("/api/alerts/:id", (req,res) => {
  const result=db.prepare("DELETE FROM alerts WHERE id=?").run(Number(req.params.id));
  if(!result.changes) return res.status(404).json({message:"Alert not found"});
  res.json({message:"Alert deleted"});
});

app.get("/api/advisories", (_req,res) => res.json([
  {id:1,audience:"Citizens",title:"Stay cool and hydrated",body:"Drink water regularly, avoid strenuous outdoor activity during peak afternoon heat, and check on vulnerable neighbours.",icon:"☀️"},
  {id:2,audience:"Farmers",title:"Protect crops and livestock",body:"Schedule field work during cooler hours, monitor soil moisture, and ensure access to drinking water and shade for livestock.",icon:"🌾"},
  {id:3,audience:"Health agencies",title:"Prepare for heat-related illness",body:"Review local heat-response readiness, communicate symptoms of heat exhaustion, and follow official public-health guidance.",icon:"🏥"},
  {id:4,audience:"Local authorities",title:"Coordinate heat response",body:"Review local observations, verify hotspot reports, and disseminate approved warnings through official channels.",icon:"🏙️"}
]));

// Optional NoSQL: MongoDB station documents CRUD
app.get("/api/nosql/stations", async (_req,res) => {
  try { const c=await getStationCollection(); const docs=await c.find().sort({_id:-1}).toArray(); res.json(docs.map(d=>({...d,id:d._id.toString(),_id:undefined}))); }
  catch(e) { res.status(503).json({message:e.message,configured:Boolean(process.env.MONGODB_URI)}); }
});
app.post("/api/nosql/stations", async (req,res) => {
  const errors=validateStation(req.body); if(errors.length) return res.status(400).json({message:"Validation failed",errors});
  try { const c=await getStationCollection(); const doc={name:req.body.name.trim(),region:req.body.region,city:req.body.city.trim(),temperature:Number(req.body.temperature),humidity:Number(req.body.humidity),latitude:Number(req.body.latitude),longitude:Number(req.body.longitude),createdAt:new Date()}; const r=await c.insertOne(doc); res.status(201).json({...doc,id:r.insertedId.toString()}); }
  catch(e) { res.status(503).json({message:e.message}); }
});
app.put("/api/nosql/stations/:id", async (req,res) => {
  const errors=validateStation(req.body); if(errors.length) return res.status(400).json({message:"Validation failed",errors});
  try { const c=await getStationCollection(); if(!ObjectId.isValid(req.params.id)) return res.status(400).json({message:"Invalid MongoDB id"}); const id=new ObjectId(req.params.id); const b=req.body; const r=await c.findOneAndUpdate({_id:id},{$set:{name:b.name.trim(),region:b.region,city:b.city.trim(),temperature:Number(b.temperature),humidity:Number(b.humidity),latitude:Number(b.latitude),longitude:Number(b.longitude)}},{returnDocument:"after"}); if(!r) return res.status(404).json({message:"Station not found"}); const d=r; res.json({...d,id:d._id.toString(),_id:undefined}); }
  catch(e) { res.status(503).json({message:e.message}); }
});
app.delete("/api/nosql/stations/:id", async (req,res) => {
  try { const c=await getStationCollection(); if(!ObjectId.isValid(req.params.id)) return res.status(400).json({message:"Invalid MongoDB id"}); const r=await c.deleteOne({_id:new ObjectId(req.params.id)}); if(!r.deletedCount) return res.status(404).json({message:"Station not found"}); res.json({message:"MongoDB station deleted"}); }
  catch(e) { res.status(503).json({message:e.message}); }
});

// MongoDB NoSQL: alerts collection CRUD (parallel to SQL /api/alerts)
app.get("/api/nosql/alerts", async (_req,res) => {
  try { const c=await getAlertCollection(); const docs=await c.find().sort({_id:-1}).toArray(); res.json(docs.map(d=>({...d,id:d._id.toString(),_id:undefined}))); }
  catch(e) { res.status(503).json({message:e.message,configured:Boolean(process.env.MONGODB_URI)}); }
});
app.post("/api/nosql/alerts", async (req,res) => {
  const errors=validateAlert(req.body); if(errors.length) return res.status(400).json({message:"Validation failed",errors});
  try { const c=await getAlertCollection(); const b=req.body; const doc={title:b.title.trim(),region:b.region,severity:b.severity,message:b.message.trim(),status:b.status || "Active",createdAt:new Date(),updatedAt:new Date()}; const r=await c.insertOne(doc); res.status(201).json({...doc,id:r.insertedId.toString()}); }
  catch(e) { res.status(503).json({message:e.message}); }
});
app.put("/api/nosql/alerts/:id", async (req,res) => {
  const errors=validateAlert(req.body); if(errors.length) return res.status(400).json({message:"Validation failed",errors});
  try { const c=await getAlertCollection(); if(!ObjectId.isValid(req.params.id)) return res.status(400).json({message:"Invalid MongoDB id"}); const id=new ObjectId(req.params.id); const b=req.body; const doc={title:b.title.trim(),region:b.region,severity:b.severity,message:b.message.trim(),status:b.status || "Active",updatedAt:new Date()}; const r=await c.findOneAndUpdate({_id:id},{$set:doc},{returnDocument:"after"}); if(!r) return res.status(404).json({message:"Alert not found"}); res.json({...r,id:r._id.toString(),_id:undefined}); }
  catch(e) { res.status(503).json({message:e.message}); }
});
app.delete("/api/nosql/alerts/:id", async (req,res) => {
  try { const c=await getAlertCollection(); if(!ObjectId.isValid(req.params.id)) return res.status(400).json({message:"Invalid MongoDB id"}); const r=await c.deleteOne({_id:new ObjectId(req.params.id)}); if(!r.deletedCount) return res.status(404).json({message:"Alert not found"}); res.json({message:"MongoDB alert deleted"}); }
  catch(e) { res.status(503).json({message:e.message}); }
});

app.use((err,_req,res,_next)=>{ console.error(err); res.status(500).json({message:"Internal server error"}); });
app.listen(PORT, () => console.log(`HeatGuard AI API running at http://localhost:${PORT}`));
