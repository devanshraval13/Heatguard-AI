import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { NavLink, Route, Routes, useLocation } from 'react-router-dom';
import { Activity, AlertTriangle, ArrowDownRight, ArrowUpRight, CloudSun, Database, LayoutDashboard, MapPin, Plus, RefreshCw, Search, ShieldCheck, ThermometerSun, Trash2, Users, X, Pencil, RadioTower, ExternalLink } from 'lucide-react';
import { api } from './api';

const regions = ['North','South','East','West','Central','North-East','North-West'];
const emptyStation = { name:'', region:'West', city:'', temperature:'', humidity:'', latitude:'', longitude:'' };
const emptyAlert = { title:'', region:'West', severity:'Orange', message:'', status:'Active' };
const severityClass = (s='') => s.toLowerCase();
function tempLevel(t) { return t >= 43 ? 'Red' : t >= 40 ? 'Orange' : t >= 37 ? 'Yellow' : 'Green'; }
function formatTime(value) { return value ? new Date(value).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'}) : '—'; }

function App() {
  const [summary,setSummary] = useState(null);
  const [stations,setStations] = useState([]);
  const [alerts,setAlerts] = useState([]);
  const [advisories,setAdvisories] = useState([]);
  const [loading,setLoading] = useState(true);
  const [apiOnline,setApiOnline] = useState(false);
  const [notice,setNotice] = useState('');
  const [search,setSearch] = useState('');
  const [stationModal,setStationModal] = useState(false);
  const [editingStation,setEditingStation] = useState(null);
  const [stationForm,setStationForm] = useState(emptyStation);
  const [formError,setFormError] = useState('');
  const [alertModal,setAlertModal] = useState(false);
  const [alertForm,setAlertForm] = useState(emptyAlert);
  const [editingAlert,setEditingAlert] = useState(null);
  const [mongoRows,setMongoRows] = useState([]);
  const [mongoMessage,setMongoMessage] = useState('');
  const [mongoForm,setMongoForm] = useState(emptyStation);
  const [mongoEditing,setMongoEditing] = useState(null);
  const location = useLocation();

  const refresh = useCallback(async () => {
    setLoading(true);
    try {
      const [s,st,a,adv] = await Promise.all([api.summary(),api.stations(search),api.alerts(),api.advisories()]);
      setSummary(s); setStations(st); setAlerts(a); setAdvisories(adv); setApiOnline(true);
    } catch (e) { setApiOnline(false); setNotice(e.message || 'Could not connect to API.'); }
    finally { setLoading(false); }
  }, [search]);

  useEffect(() => { refresh(); }, [refresh]);
  useEffect(() => { if (!notice) return; const id = setTimeout(() => setNotice(''), 4500); return () => clearTimeout(id); }, [notice]);

  const riskCounts = useMemo(() => ({
    red: stations.filter(s=>tempLevel(s.temperature)==='Red').length,
    orange: stations.filter(s=>tempLevel(s.temperature)==='Orange').length,
    average: stations.length ? (stations.reduce((n,s)=>n+Number(s.temperature),0)/stations.length).toFixed(1) : '—'
  }), [stations]);

  const saveStation = async (e) => {
    e.preventDefault(); setFormError('');
    const t=Number(stationForm.temperature), h=Number(stationForm.humidity), lat=Number(stationForm.latitude), lon=Number(stationForm.longitude);
    if (!stationForm.name.trim() || !stationForm.city.trim()) return setFormError('Station name and city are required.');
    if (stationForm.temperature==='' || !Number.isFinite(t) || t < -10 || t > 60) return setFormError('Temperature must be between -10°C and 60°C.');
    if (stationForm.humidity==='' || !Number.isInteger(h) || h < 0 || h > 100) return setFormError('Humidity must be a whole number from 0 to 100.');
    if (stationForm.latitude==='' || !Number.isFinite(lat) || lat < -90 || lat > 90) return setFormError('Latitude must be between -90 and 90.');
    if (stationForm.longitude==='' || !Number.isFinite(lon) || lon < -180 || lon > 180) return setFormError('Longitude must be between -180 and 180.');
    const payload={...stationForm,temperature:t,humidity:h,latitude:lat,longitude:lon};
    try {
      if(editingStation) await api.updateStation(editingStation.id,payload); else await api.createStation(payload);
      setStationModal(false); setEditingStation(null); setStationForm(emptyStation); setNotice(editingStation?'Station updated.':'Station added.'); await refresh();
    } catch(e) { setFormError(e.message); }
  };
  const openEditStation = (s) => { setEditingStation(s); setStationForm({...s,temperature:String(s.temperature),humidity:String(s.humidity),latitude:String(s.latitude),longitude:String(s.longitude)}); setFormError(''); setStationModal(true); };
  const removeStation = async (s) => { if(!window.confirm(`Delete ${s.name}?`)) return; try { await api.deleteStation(s.id); setNotice('Station deleted.'); await refresh(); } catch(e) { setNotice(e.message); } };
  const saveAlert = async (e) => {
    e.preventDefault();
    if(!alertForm.title.trim() || !alertForm.message.trim()) return setNotice('Alert title and message are required.');
    try {
      if(editingAlert) await api.updateAlert(editingAlert.id,alertForm); else await api.createAlert(alertForm);
      setAlertModal(false); setEditingAlert(null); setAlertForm(emptyAlert); setNotice(editingAlert?'Alert updated.':'Alert created.'); await refresh();
    } catch(e) { setNotice(e.message); }
  };
  const removeAlert = async (a) => { if(!window.confirm(`Delete alert "${a.title}"?`)) return; try { await api.deleteAlert(a.id); setNotice('Alert deleted.'); await refresh(); } catch(e) { setNotice(e.message); } };
  const loadMongo = async () => { try { setMongoRows(await api.mongoStations()); setMongoMessage('MongoDB connected.'); } catch(e) { setMongoRows([]); setMongoMessage(e.message); } };
  const saveMongo = async (e) => {
    e.preventDefault();
    try {
      const payload={...mongoForm,temperature:Number(mongoForm.temperature),humidity:Number(mongoForm.humidity),latitude:Number(mongoForm.latitude),longitude:Number(mongoForm.longitude)};
      if(!payload.name.trim() || !payload.city.trim() || mongoForm.temperature==='' || mongoForm.humidity==='' || mongoForm.latitude==='' || mongoForm.longitude==='') return setMongoMessage('Complete every field before saving.');
      if(mongoEditing) await api.updateMongoStation(mongoEditing.id,payload); else await api.createMongoStation(payload);
      setMongoForm(emptyStation); setMongoEditing(null); await loadMongo();
    } catch(e) { setMongoMessage(e.message); }
  };
  const editMongo = (s) => { setMongoEditing(s); setMongoForm({...s,temperature:String(s.temperature),humidity:String(s.humidity),latitude:String(s.latitude),longitude:String(s.longitude)}); };
  const deleteMongo = async (s) => { if(!window.confirm(`Delete ${s.name} from MongoDB?`)) return; try { await api.deleteMongoStation(s.id); await loadMongo(); } catch(e) { setMongoMessage(e.message); } };

  const openNewStation = () => { setEditingStation(null); setStationForm(emptyStation); setFormError(''); setStationModal(true); };
  const openNewAlert = () => { setEditingAlert(null); setAlertForm(emptyAlert); setAlertModal(true); };
  const pageTitle = location.pathname === '/stations' ? 'Weather stations' : location.pathname === '/alerts' ? 'Alert management' : location.pathname === '/advisories' ? 'Public advisories' : location.pathname === '/database' ? 'Database lab' : 'Climate intelligence';
  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-mark"><ThermometerSun size={23}/></div><div><b>HeatGuard<span>AI</span></b><small>CLIMATE INTELLIGENCE</small></div></div>
      <div className="workspace-label">WORKSPACE</div>
      <nav>
        <NavLink end to="/" className={({isActive})=>isActive?'nav-item active':'nav-item'}><LayoutDashboard size={18}/>Overview</NavLink>
        <NavLink to="/stations" className={({isActive})=>isActive?'nav-item active':'nav-item'}><RadioTower size={18}/>Weather stations <span className="nav-count">{stations.length}</span></NavLink>
        <NavLink to="/alerts" className={({isActive})=>isActive?'nav-item active':'nav-item'}><AlertTriangle size={18}/>Alerts <span className="nav-count alert-count">{alerts.filter(a=>a.status==='Active').length}</span></NavLink>
        <NavLink to="/advisories" className={({isActive})=>isActive?'nav-item active':'nav-item'}><ShieldCheck size={18}/>Advisories</NavLink>
        <NavLink to="/database" className={({isActive})=>isActive?'nav-item active':'nav-item'}><Database size={18}/>Database lab</NavLink>
      </nav>
      <div className="sidebar-bottom"><div className="sync-dot"></div><div><b>API connection</b><small>{apiOnline?'Express server connected':'Waiting for backend'}</small></div><span className={`connection-dot ${apiOnline?'online':''}`}></span></div>
      <div className="sidebar-foot">KJS-CES-01 · MINI PROJECT<br/>Educational demo · v1.0</div>
    </aside>
    <main className="main-area">
      <header className="topbar"><div><div className="breadcrumb">HeatGuard AI <span>/</span> {pageTitle}</div><h1>{pageTitle}</h1></div><div className="top-actions"><div className="live-pill"><span></span> {apiOnline?'System online':'API offline'}</div><button className="icon-btn" onClick={refresh} title="Refresh data"><RefreshCw size={17}/></button><div className="avatar">HG</div></div></header>
      {notice && <div className="toast"><span>{notice}</span><button onClick={()=>setNotice('')}><X size={15}/></button></div>}
      {!apiOnline && !loading && <div className="offline-banner"><AlertTriangle size={18}/><div><b>Backend is not connected</b><span>Start the backend with <code>npm run dev</code> inside the backend folder, then refresh.</span></div></div>}
      <Routes>
        <Route path="/" element={<Dashboard summary={summary} stations={stations} alerts={alerts} advisories={advisories} loading={loading} riskCounts={riskCounts} onAddStation={openNewStation} onAddAlert={openNewAlert} onEditStation={openEditStation} onDeleteStation={removeStation} onEditAlert={a=>{setEditingAlert(a);setAlertForm({...a});setAlertModal(true);}} onDeleteAlert={removeAlert} onNavigate={p=>window.history.pushState({},'',p)}/>}/>
        <Route path="/stations" element={<StationsPage stations={stations} loading={loading} search={search} setSearch={setSearch} onAdd={openNewStation} onEdit={openEditStation} onDelete={removeStation}/>}/>
        <Route path="/alerts" element={<AlertsPage alerts={alerts} onAdd={openNewAlert} onEdit={a=>{setEditingAlert(a);setAlertForm({...a});setAlertModal(true);}} onDelete={removeAlert}/>}/>
        <Route path="/advisories" element={<AdvisoriesPage advisories={advisories}/>}/>
        <Route path="/database" element={<DatabasePage rows={mongoRows} message={mongoMessage} form={mongoForm} setForm={setMongoForm} editing={mongoEditing} setEditing={setMongoEditing} onLoad={loadMongo} onSave={saveMongo} onEdit={editMongo} onDelete={deleteMongo}/>}/>
        <Route path="*" element={<div className="panel"><h2>Page not found</h2><p>Choose a page from the sidebar.</p></div>}/>
      </Routes>
      <footer className="page-footer"><span>HeatGuard AI · KJS-CES-01</span><span>Sample data only · Not an official weather warning</span></footer>
    </main>
    {stationModal && <Modal title={editingStation?'Edit weather station':'Add weather station'} onClose={()=>setStationModal(false)}><form className="form-grid" onSubmit={saveStation} noValidate>
      {formError && <div className="form-error full">{formError}</div>}
      <Field label="Station name" value={stationForm.name} onChange={v=>setStationForm({...stationForm,name:v})} placeholder="e.g. Pune Central AWS" required/>
      <Field label="City" value={stationForm.city} onChange={v=>setStationForm({...stationForm,city:v})} placeholder="e.g. Pune" required/>
      <label className="field"><span>IMD region</span><select value={stationForm.region} onChange={e=>setStationForm({...stationForm,region:e.target.value})}>{regions.map(r=><option key={r}>{r}</option>)}</select></label>
      <Field label="Temperature (°C)" type="number" value={stationForm.temperature} onChange={v=>setStationForm({...stationForm,temperature:v})} placeholder="35.5" required/>
      <Field label="Humidity (%)" type="number" value={stationForm.humidity} onChange={v=>setStationForm({...stationForm,humidity:v})} placeholder="45" required/>
      <Field label="Latitude" type="number" value={stationForm.latitude} onChange={v=>setStationForm({...stationForm,latitude:v})} placeholder="18.5204" required/>
      <Field label="Longitude" type="number" value={stationForm.longitude} onChange={v=>setStationForm({...stationForm,longitude:v})} placeholder="73.8567" required/>
      <div className="form-actions full"><button type="button" className="btn secondary" onClick={()=>setStationModal(false)}>Cancel</button><button className="btn primary" type="submit">{editingStation?'Save changes':'Add station'}</button></div>
    </form></Modal>}
    {alertModal && <Modal title={editingAlert?'Edit alert':'Create alert'} onClose={()=>setAlertModal(false)}><form className="form-grid" onSubmit={saveAlert}>
      <Field label="Alert title" value={alertForm.title} onChange={v=>setAlertForm({...alertForm,title:v})} placeholder="High heat stress" required/>
      <label className="field"><span>Region</span><select value={alertForm.region} onChange={e=>setAlertForm({...alertForm,region:e.target.value})}>{regions.map(r=><option key={r}>{r}</option>)}</select></label>
      <label className="field"><span>Severity</span><select value={alertForm.severity} onChange={e=>setAlertForm({...alertForm,severity:e.target.value})}>{['Red','Orange','Yellow','Green'].map(r=><option key={r}>{r}</option>)}</select></label>
      <label className="field"><span>Status</span><select value={alertForm.status} onChange={e=>setAlertForm({...alertForm,status:e.target.value})}>{['Active','Monitoring','Resolved'].map(r=><option key={r}>{r}</option>)}</select></label>
      <label className="field full"><span>Message</span><textarea value={alertForm.message} onChange={e=>setAlertForm({...alertForm,message:e.target.value})} rows="3" required placeholder="Describe the conditions and recommended action"/></label>
      <div className="form-actions full"><button type="button" className="btn secondary" onClick={()=>setAlertModal(false)}>Cancel</button><button className="btn primary" type="submit">{editingAlert?'Save changes':'Create alert'}</button></div>
    </form></Modal>}
  </div>;
}

function Dashboard({summary,stations,alerts,advisories,loading,riskCounts,onAddStation,onAddAlert,onEditStation,onDeleteStation,onEditAlert,onDeleteAlert}) {
  const hottest = [...stations].sort((a,b)=>b.temperature-a.temperature)[0];
  const regional = useMemo(()=> {
    const counts={}; stations.forEach(s=>{counts[s.region]=(counts[s.region]||0)+1;});
    return Object.entries(counts).sort((a,b)=>b[1]-a[1]);
  },[stations]);
  return <div className="content">
    <section className="hero-banner"><div className="hero-copy"><div className="eyebrow"><span className="pulse"></span> CLIMATE MONITORING NETWORK <span className="hero-tag">DEMO ENVIRONMENT</span></div><h2>Turning heat data into<br/><em>early action.</em></h2><p>Localized observations, heat-risk signals, and stakeholder advisories in one decision-support workspace.</p><div className="hero-buttons"><a href="/stations" className="btn light">Explore stations <ArrowDownRight size={16}/></a><button className="btn ghost-light" onClick={onAddAlert}><Plus size={16}/> Create alert</button></div></div><div className="hero-visual"><div className="sun-halo"><div className="sun-core"><ThermometerSun size={43}/></div></div><div className="floating-stat stat-top"><span>NETWORK AVG.</span><b>{riskCounts.average}°C</b><small>Across {stations.length} stations</small></div><div className="floating-stat stat-bottom"><span>HIGH-RISK SITES</span><b>{riskCounts.red+riskCounts.orange}</b><small>Red + orange categories</small></div><div className="orbit orbit-one"></div><div className="orbit orbit-two"></div></div></section>
    <div className="section-heading"><div><h2>Network overview</h2><p>Snapshot of sample weather station observations</p></div><span className="updated-label"><span className="tiny-dot"></span> {loading?'Updating…':'Updated '+formatTime(new Date())}</span></div>
    <div className="metric-grid">
      <Metric icon={<RadioTower/>} label="AWS stations" value={summary?.stationCount ?? '—'} note="Monitoring locations" tone="blue"/>
      <Metric icon={<ThermometerSun/>} label="Average temperature" value={summary?`${summary.averageTemperature}°C`:'—'} note="Across active stations" tone="orange"/>
      <Metric icon={<AlertTriangle/>} label="Active alerts" value={summary?.activeAlerts ?? '—'} note={`${summary?.redAlerts ?? 0} red-severity alerts`} tone="red"/>
      <Metric icon={<Activity/>} label="High-risk stations" value={riskCounts.red+riskCounts.orange} note="Red and orange categories" tone="purple"/>
    </div>
    <div className="two-column">
      <section className="panel"><div className="panel-heading"><div><h3>Station temperature watch</h3><p>Highest readings across the network</p></div><a className="text-link" href="/stations">View all <ExternalLink size={13}/></a></div>
        {stations.length===0?<Empty text="No stations match your search."/>:<div className="station-list">{stations.slice(0,5).map(s=><StationRow key={s.id} station={s} onEdit={onEditStation} onDelete={onDeleteStation}/>)}</div>}
        <div className="panel-bottom"><span><span className="legend-dot red"></span> Red ≥43°C</span><span><span className="legend-dot orange"></span> Orange ≥40°C</span><span><span className="legend-dot yellow"></span> Yellow ≥37°C</span></div>
      </section>
      <section className="panel"><div className="panel-heading"><div><h3>Regional monitoring</h3><p>Stations by monitored region</p></div><MapPin size={18} className="muted-icon"/></div>
        <div className="region-chart">{regional.map(([region,count])=><div className="region-row" key={region}><span>{region}</span><div className="bar-track"><div className="bar-fill" style={{width:`${Math.max(8,count/Math.max(...regional.map(r=>r[1]),1)*100)}%`}}></div></div><b>{count}</b></div>)}</div>
        <div className="region-note"><MapPin size={15}/> Region grouping is for classroom demonstration, not an official IMD regional classification.</div>
      </section>
    </div>
    <div className="two-column lower-grid">
      <section className="panel"><div className="panel-heading"><div><h3>Latest heat alerts</h3><p>Monitor and manage local risk signals</p></div><button className="small-action" onClick={onAddAlert}><Plus size={15}/> New alert</button></div>
        {alerts.slice(0,4).map(a=><AlertRow key={a.id} alert={a} onEdit={onEditAlert} onDelete={onDeleteAlert}/>)}{alerts.length===0&&<Empty text="No alerts created yet."/>}
      </section>
      <section className="panel advisory-preview"><div className="panel-heading"><div><h3>Actionable advisories</h3><p>Guidance by stakeholder group</p></div><ShieldCheck size={18} className="muted-icon"/></div>
        {advisories.slice(0,3).map(a=><div className="advisory-mini" key={a.id}><div className="advisory-icon">{a.icon}</div><div><b>{a.audience}</b><p>{a.title}</p></div><span className="advisory-arrow">↗</span></div>)}
      </section>
    </div>
    <section className="callout"><div className="callout-icon"><Users size={20}/></div><div><b>Designed for coordinated heat response</b><p>Support citizens, farmers, health agencies, and local authorities with region-specific monitoring and timely information.</p></div><button className="btn secondary" onClick={onAddStation}><Plus size={15}/> Add AWS station</button></section>
    <p className="disclaimer"><ShieldCheck size={14}/> This educational dashboard uses sample data and simple threshold categories. It is not an AI model or an official IMD forecast.</p>
  </div>;
}
function Metric({icon,label,value,note,tone}) { return <div className="metric-card"><div className={`metric-icon ${tone}`}>{icon}</div><div className="metric-label">{label}</div><div className="metric-value">{value}</div><div className="metric-note">{note}</div></div>; }
function StationRow({station:s,onEdit,onDelete}) { const level=tempLevel(s.temperature); return <div className="station-row"><div className={`station-symbol ${severityClass(level)}`}><ThermometerSun size={18}/></div><div className="station-main"><b>{s.name}</b><span><MapPin size={12}/> {s.city}, {s.region}</span></div><div className="station-reading"><b>{Number(s.temperature).toFixed(1)}°</b><span>{s.humidity}% humidity</span></div><span className={`severity-badge ${severityClass(level)}`}>{level}</span><div className="row-actions"><button title="Edit" onClick={()=>onEdit(s)}><Pencil size={14}/></button><button title="Delete" onClick={()=>onDelete(s)}><Trash2 size={14}/></button></div></div>; }
function AlertRow({alert:a,onEdit,onDelete}) { return <div className="alert-row"><div className={`alert-symbol ${severityClass(a.severity)}`}><AlertTriangle size={17}/></div><div className="alert-main"><b>{a.title}</b><p>{a.message}</p><span>{a.region} region · {a.status}</span></div><span className={`severity-badge ${severityClass(a.severity)}`}>{a.severity}</span><div className="row-actions"><button title="Edit alert" onClick={()=>onEdit(a)}><Pencil size={14}/></button><button title="Delete alert" onClick={()=>onDelete(a)}><Trash2 size={14}/></button></div></div>; }
function StationsPage({stations,loading,search,setSearch,onAdd,onEdit,onDelete}) { return <div className="content"><div className="page-toolbar"><div><p className="lead">Manage localized AWS observations used for heat-risk monitoring.</p></div><button className="btn primary" onClick={onAdd}><Plus size={16}/> Add station</button></div><section className="panel"><div className="table-tools"><div className="search-box"><Search size={16}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search station, city, or region..."/></div><span className="table-count">{stations.length} stations</span></div><div className="table-wrap"><table><thead><tr><th>Station / city</th><th>Region</th><th>Temperature</th><th>Humidity</th><th>Coordinates</th><th>Risk</th><th>Actions</th></tr></thead><tbody>{stations.map(s=><tr key={s.id}><td><b>{s.name}</b><small>{s.city}</small></td><td>{s.region}</td><td><b>{Number(s.temperature).toFixed(1)}°C</b></td><td>{s.humidity}%</td><td className="coordinate">{Number(s.latitude).toFixed(3)}, {Number(s.longitude).toFixed(3)}</td><td><span className={`severity-badge ${severityClass(tempLevel(s.temperature))}`}>{tempLevel(s.temperature)}</span></td><td><div className="table-actions"><button onClick={()=>onEdit(s)} title="Edit"><Pencil size={15}/></button><button onClick={()=>onDelete(s)} title="Delete"><Trash2 size={15}/></button></div></td></tr>)}</tbody></table>{!stations.length&&<Empty text={loading?'Loading stations…':'No stations found.'}/>}</div></section><div className="note-strip"><RadioTower size={17}/><span>Station readings are editable demonstration data. Real AWS/IMD data integration would require an authorized data feed.</span></div></div>; }
function AlertsPage({alerts,onAdd,onEdit,onDelete}) { return <div className="content"><div className="page-toolbar"><p className="lead">Create, update, resolve, or delete heat-risk signals.</p><button className="btn primary" onClick={onAdd}><Plus size={16}/> Create alert</button></div><div className="alert-summary"><div><span>All alerts</span><b>{alerts.length}</b></div><div><span>Active</span><b>{alerts.filter(a=>a.status==='Active').length}</b></div><div><span>Red severity</span><b>{alerts.filter(a=>a.severity==='Red'&&a.status==='Active').length}</b></div></div><section className="panel"><div className="panel-heading"><div><h3>Alert register</h3><p>SQL-backed records · CRUD enabled</p></div><span className="db-pill"><Database size={13}/> SQLite</span></div>{alerts.map(a=><AlertRow key={a.id} alert={a} onEdit={onEdit} onDelete={onDelete}/>)}{!alerts.length&&<Empty text="No alerts. Create one to get started."/>}</section></div>; }
function AdvisoriesPage({advisories}) { return <div className="content"><p className="lead">Sample stakeholder-specific advisory templates inspired by the KJS-CES-01 use case.</p><div className="advisory-grid">{advisories.map(a=><article className="advisory-card" key={a.id}><div className="advisory-icon large">{a.icon}</div><span className="audience-label">FOR {a.audience.toUpperCase()}</span><h3>{a.title}</h3><p>{a.body}</p><div className="advisory-card-foot"><ShieldCheck size={15}/> Review with authorized experts before dissemination</div></article>)}</div><div className="note-strip"><AlertTriangle size={17}/><span>These are general educational examples, not official health or meteorological advice. Follow current guidance from relevant authorities.</span></div></div>; }
function DatabasePage({rows,message,form,setForm,editing,setEditing,onLoad,onSave,onEdit,onDelete}) { return <div className="content"><div className="page-toolbar"><div><p className="lead">Compare relational SQL storage with document-based NoSQL CRUD.</p></div><button className="btn primary" onClick={onLoad}><RefreshCw size={15}/> Connect / refresh MongoDB</button></div><div className="database-explain"><div className="db-card"><div className="db-card-head"><Database/><span className="db-pill">DEFAULT</span></div><h3>SQL · SQLite</h3><p>Stations and alerts are stored in relational tables. CRUD endpoints work immediately without installing a database server.</p><div className="db-status"><span className="status-dot green"></span> Active local database</div></div><div className="db-card"><div className="db-card-head"><Activity/><span className="db-pill optional">OPTIONAL</span></div><h3>NoSQL · MongoDB</h3><p>Station documents are stored in a MongoDB collection. Configure <code>MONGODB_URI</code> to enable this panel.</p><div className="db-status"><span className={`status-dot ${message.includes('connected')?'green':'amber'}`}></span> {message||'Not checked yet'}</div></div></div><section className="panel mongo-panel"><div className="panel-heading"><div><h3>MongoDB station collection</h3><p>Optional NoSQL CRUD demonstration</p></div><span className="db-pill">stations</span></div>{message&&!message.includes('connected')&&<div className="form-error">{message}</div>}<form className="mongo-form" onSubmit={onSave}><Field label="Station name" value={form.name} onChange={v=>setForm({...form,name:v})} placeholder="Station name" required/><Field label="City" value={form.city} onChange={v=>setForm({...form,city:v})} placeholder="City" required/><label className="field"><span>Region</span><select value={form.region} onChange={e=>setForm({...form,region:e.target.value})}>{regions.map(r=><option key={r}>{r}</option>)}</select></label><Field label="Temp °C" type="number" value={form.temperature} onChange={v=>setForm({...form,temperature:v})} placeholder="40" required/><Field label="Humidity %" type="number" value={form.humidity} onChange={v=>setForm({...form,humidity:v})} placeholder="30" required/><Field label="Latitude" type="number" value={form.latitude} onChange={v=>setForm({...form,latitude:v})} placeholder="18.52" required/><Field label="Longitude" type="number" value={form.longitude} onChange={v=>setForm({...form,longitude:v})} placeholder="73.85" required/><button className="btn primary" type="submit">{editing?'Update document':'Add document'}</button>{editing&&<button className="btn secondary" type="button" onClick={()=>{setEditing(null);setForm(emptyStation);}}>Cancel edit</button>}</form><div className="table-wrap"><table><thead><tr><th>Document</th><th>Region</th><th>Temp</th><th>Humidity</th><th>Actions</th></tr></thead><tbody>{rows.map(s=><tr key={s.id}><td><b>{s.name}</b><small>{s.city}</small></td><td>{s.region}</td><td>{s.temperature}°C</td><td>{s.humidity}%</td><td><div className="table-actions"><button onClick={()=>onEdit(s)} title="Edit"><Pencil size={15}/></button><button onClick={()=>onDelete(s)} title="Delete"><Trash2 size={15}/></button></div></td></tr>)}</tbody></table>{rows.length===0&&<Empty text="No MongoDB documents loaded. Configure MongoDB, then connect / refresh."/>}</div></section><div className="note-strip"><Database size={17}/><span>SQL CRUD routes: <code>/api/stations</code> and <code>/api/alerts</code>. NoSQL CRUD routes: <code>/api/nosql/stations</code>.</span></div></div>; }
function Field({label,value,onChange,placeholder,type='text',required=false}) { return <label className="field"><span>{label}{required?' *':''}</span><input type={type} value={value ?? ''} onChange={e=>onChange(e.target.value)} placeholder={placeholder} required={required} step={type==='number'?'any':undefined}/></label>; }
function Modal({title,onClose,children}) { useEffect(()=>{const onKey=e=>e.key==='Escape'&&onClose();window.addEventListener('keydown',onKey);return()=>window.removeEventListener('keydown',onKey);},[onClose]); return <div className="modal-backdrop" onMouseDown={e=>e.target===e.currentTarget&&onClose()}><section className="modal"><div className="modal-head"><div><span className="eyebrow">HEATGUARD AI / DATA ENTRY</span><h2>{title}</h2></div><button className="icon-btn" onClick={onClose}><X size={18}/></button></div>{children}</section></div>; }
function Empty({text}) { return <div className="empty-state"><CloudSun size={24}/><span>{text}</span></div>; }
export default App;
