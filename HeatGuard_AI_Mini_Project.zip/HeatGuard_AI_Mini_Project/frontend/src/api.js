const API_BASE = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';
async function request(path, options = {}) {
  const response = await fetch(`${API_BASE}${path}`, {
    ...options,
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) }
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.errors?.join(' ') || data.message || `Request failed (${response.status})`);
  return data;
}
export const api = {
  health: () => request('/health'),
  summary: () => request('/summary'),
  stations: (search='') => request(`/stations${search ? `?search=${encodeURIComponent(search)}` : ''}`),
  createStation: (data) => request('/stations', { method:'POST', body:JSON.stringify(data) }),
  updateStation: (id,data) => request(`/stations/${id}`, { method:'PUT', body:JSON.stringify(data) }),
  deleteStation: (id) => request(`/stations/${id}`, { method:'DELETE' }),
  alerts: () => request('/alerts'),
  createAlert: (data) => request('/alerts', { method:'POST', body:JSON.stringify(data) }),
  updateAlert: (id,data) => request(`/alerts/${id}`, { method:'PUT', body:JSON.stringify(data) }),
  deleteAlert: (id) => request(`/alerts/${id}`, { method:'DELETE' }),
  advisories: () => request('/advisories'),
  mongoHealth: () => request('/nosql/health'),
  mongoStations: () => request('/nosql/stations'),
  createMongoStation: (data) => request('/nosql/stations', { method:'POST', body:JSON.stringify(data) }),
  updateMongoStation: (id,data) => request(`/nosql/stations/${id}`, { method:'PUT', body:JSON.stringify(data) }),
  deleteMongoStation: (id) => request(`/nosql/stations/${id}`, { method:'DELETE' }),
  mongoAlerts: () => request('/nosql/alerts'),
  createMongoAlert: (data) => request('/nosql/alerts', { method:'POST', body:JSON.stringify(data) }),
  updateMongoAlert: (id,data) => request(`/nosql/alerts/${id}`, { method:'PUT', body:JSON.stringify(data) }),
  deleteMongoAlert: (id) => request(`/nosql/alerts/${id}`, { method:'DELETE' })
};
